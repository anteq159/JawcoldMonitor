from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, field_validator
from app.schemas.device_profile import RegisterDefinitionOut

# Mirrored by MAX_CARD_PARAMS in frontend/src/api/devices.ts - the tile only
# has room for three values before it stops being scannable at a glance.
MAX_CARD_PARAMETERS = 3


class ParameterOut(BaseModel):
    id: int
    name: str
    unit: Optional[str] = None
    description: Optional[str] = None
    register_address: int
    register_type: str
    data_type: str
    scale_factor: float
    offset: float
    threshold_min: Optional[float] = None
    threshold_max: Optional[float] = None
    enabled: bool

    model_config = {"from_attributes": True}


class ProfileOut(BaseModel):
    id: int
    name: str
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    source: str = "local"
    registers: List[RegisterDefinitionOut] = []

    model_config = {"from_attributes": True}


class DeviceOut(BaseModel):
    id: int
    name: str
    modbus_address: int
    port: str
    baudrate: int
    parity: str
    stopbits: int
    timeout: float
    poll_interval_seconds: Optional[int] = None
    profile_id: Optional[int] = None
    status: str
    recognition_status: str = "recognized"
    detected_manufacturer: Optional[str] = None
    location: Optional[str] = None
    group_name: Optional[str] = None
    description: Optional[str] = None
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    created_at: datetime
    profile: Optional[ProfileOut] = None
    parameters: List[ParameterOut] = []
    hidden_parameters: List[str] = []
    parameter_aliases: Dict[str, str] = {}
    parameter_units: Dict[str, str] = {}
    card_parameters: List[str] = []
    chart_hidden_parameters: List[str] = []

    model_config = {"from_attributes": True}


class DeviceCreate(BaseModel):
    name: str
    modbus_address: int
    port: str = "/dev/ttyUSB0"
    baudrate: int = 9600
    parity: str = "N"
    stopbits: int = 1
    timeout: float = 0.15
    profile_id: Optional[int] = None
    location: Optional[str] = None
    group_name: Optional[str] = None
    description: Optional[str] = None


class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    location: Optional[str] = None
    group_name: Optional[str] = None
    description: Optional[str] = None
    profile_id: Optional[int] = None
    baudrate: Optional[int] = None
    timeout: Optional[float] = None
    poll_interval_seconds: Optional[int] = None
    hidden_parameters: Optional[List[str]] = None
    parameter_aliases: Optional[Dict[str, str]] = None
    parameter_units: Optional[Dict[str, str]] = None
    card_parameters: Optional[List[str]] = None
    chart_hidden_parameters: Optional[List[str]] = None

    @field_validator("card_parameters")
    @classmethod
    def _card_params_sane(cls, v):
        if v is None:
            return v
        if len(v) > MAX_CARD_PARAMETERS:
            raise ValueError(f"Na kafelku można pokazać maksymalnie {MAX_CARD_PARAMETERS} wartości")
        if len(set(v)) != len(v):
            raise ValueError("Powtórzona nazwa parametru")
        for name in v:
            if len(name) > 128:
                raise ValueError("Nazwa parametru jest za długa")
        return v

    @field_validator("chart_hidden_parameters")
    @classmethod
    def _chart_hidden_sane(cls, v):
        if v is None:
            return v
        if len(v) > 200:
            raise ValueError("Za dużo ukrytych serii")
        for name in v:
            if len(name) > 128:
                raise ValueError("Nazwa parametru jest za długa")
        return v

    @field_validator("parameter_units")
    @classmethod
    def _units_sane(cls, v):
        if v is None:
            return v
        if len(v) > 200:
            raise ValueError("Za dużo nadpisań jednostek")
        for key, unit in v.items():
            if len(key) > 128 or len(unit) > 16:
                raise ValueError("Jednostka może mieć maks. 16 znaków")
        return v


class RegisterWriteRequest(BaseModel):
    name: str
    value: float


class RegisterWriteResult(BaseModel):
    name: str
    value: float
    unit: Optional[str] = None


class ManufacturerLookupResult(BaseModel):
    simulated: bool
    detected_manufacturer: Optional[str] = None
    message: str
    suggested_next_step: str


class DiscoveredDeviceOut(BaseModel):
    modbus_address: int
    suggested_name: str
    detected_manufacturer: Optional[str] = None
    matched_profile_id: Optional[int] = None
    matched_profile_name: Optional[str] = None
