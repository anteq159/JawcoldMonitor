from typing import Optional, List
from sqlalchemy import String, Integer, Float, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import Base, TimestampMixin


class DeviceProfile(Base, TimestampMixin):
    __tablename__ = "device_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    manufacturer: Mapped[Optional[str]] = mapped_column(String(128))
    model: Mapped[Optional[str]] = mapped_column(String(128))
    description: Mapped[Optional[str]] = mapped_column(String(512))
    register_map: Mapped[Optional[dict]] = mapped_column(JSONB)
    source: Mapped[str] = mapped_column(String(16), default="local")

    registers: Mapped[List["RegisterDefinition"]] = relationship(
        "RegisterDefinition", back_populates="profile", cascade="all, delete-orphan", lazy="selectin",
        order_by="RegisterDefinition.position",
    )


class RegisterDefinition(Base):
    __tablename__ = "register_definitions"

    id: Mapped[int] = mapped_column(primary_key=True)
    profile_id: Mapped[int] = mapped_column(ForeignKey("device_profiles.id"), nullable=False)
    # Display order within the profile's register map - the Konfiguracja
    # editor lets a user reorder rows and this is what persists that
    # order (without it, the relationship would fall back to insertion/id
    # order, which isn't reorderable once rows already exist).
    position: Mapped[int] = mapped_column(Integer, default=0)
    address: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(64), nullable=False)
    unit: Mapped[Optional[str]] = mapped_column(String(16))
    description: Mapped[Optional[str]] = mapped_column(String(256))
    data_type: Mapped[str] = mapped_column(String(16), default="uint16")
    scale_factor: Mapped[float] = mapped_column(Float, default=1.0)
    writable: Mapped[bool] = mapped_column(Boolean, default=False)
    is_alarm_register: Mapped[bool] = mapped_column(Boolean, default=False)
    # "holding" (default, function 3/6/16) | "input" (function 4,
    # read-only) | "coil" (function 1, single bit) | "discrete_input"
    # (function 2, read-only single bit). See RegisterMapEntry in
    # drivers/base.py for why this exists.
    register_type: Mapped[str] = mapped_column(String(16), default="holding")

    profile: Mapped[DeviceProfile] = relationship("DeviceProfile", back_populates="registers")
