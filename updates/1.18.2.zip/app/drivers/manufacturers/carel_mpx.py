import math
import random
from typing import Dict, List, Optional

from app.drivers.base import AbstractControllerDriver, RegisterMapEntry, ControllerModel, AlarmDescription
from app.drivers.registry import register_driver


@register_driver("Carel MPX")
class CarelMPXDriver(AbstractControllerDriver):
    """Carel MPXPRO-series controller.

    Register addresses were reverse-engineered by live Modbus scan against
    a real MPXPRO on site (2026-07-09), cross-referenced against Carel's
    own MPXPRO supervisor device model (cfvarmdl/cfdescvar_PL). The key
    finding: Carel's documented "Analogue/Digital variable index" is
    1-based (matches what a technician sees on the controller/HMI, e.g.
    "register 8"), while pymodbus's read_holding_registers()/read_coils()
    address parameter is the 0-based wire address - so the real Modbus
    address is (Carel variable index - 1), not the index itself. This one
    off-by-one was the entire bug in the two previous driver revisions:
    it produced physically impossible readings (-204.8°C, -806.4 K) and,
    for the alarm relay specifically, read the wrong coil entirely -
    address 115 is "s_ReleInvertedAlarm" (active when there is NO alarm),
    one past the real summary alarm coil "s_ReleAlarm" at 114 - which is
    exactly why 1.16.0/1.16.1 logged a false hardware alarm right after
    startup.

    Every register below was confirmed live. "St" (39) and "Sonda 1/2/3"
    (7/8/9) were confirmed by changing the value on the controller's own
    keypad and watching it update on the panel. "rd" (41) and "P3" (61)
    were confirmed the same way 2026-07-09 (set to 2.0°C / 7.0K on the
    keypad, matched exactly on re-scan). Sd, SH and the EEV registers
    (Po2 returns a Modbus exception) read back as "not installed" on real
    hardware, so they're left out rather than shown as fake sensors.

    Sensor fault coils: only S1-S3's (12/13/14) were confirmed by an
    actual connect/disconnect transition (1 -> 0). S6/S7's guessed fault
    coils (17/18) were tested the same way on 2026-07-09 and failed -
    they stayed 0 after S6/S7 were physically disconnected - so they were
    removed rather than left showing a false "OK". S4/S5's fault coils
    (15/16) were only ever observed at 0 while connected, never through a
    real disconnect - unconfirmed, kept for now but don't fully trust
    them. The sensor VALUE registers themselves (holding, not the fault
    coils) reliably show the physically-impossible "-204.8°C" pattern
    when a probe isn't wired, regardless of whether the fault coil works,
    so that's the more dependable disconnect signal.

    2026-07-09 second batch: dt1/A0/AL/AH/F1/Frd/F5/P3/P7 and coil A1 were
    confirmed by reading 15 values directly off the controller's own
    keypad and matching every single one exactly on a live re-scan (e.g.
    F5 independently reproduced the 50.0 already seen at that address in
    an earlier blind scan). "Sd1" was reported as 25.8°C and matched
    closely (25.6°C) at the "Sd" address - close enough (live drift) to
    accept now that a probe is evidently wired there (it read the
    "not installed" -812.8 pattern before). Deliberately NOT added despite
    being asked for: "dP1" (176), "AA" (187) and "Ad" (188) - none matched
    the reported value at their cfvarmdl-derived address, so the address
    is wrong and needs a real disconnect/keypad-change test like the
    others got, not a guess. "SH" matches the known not-installed pattern
    (-806.4) rather than a real reading. "PPU" has no corresponding
    variable in the supplied Carel model files at all."""

    manufacturer = "Carel MPX"

    def default_register_map(self) -> List[RegisterMapEntry]:
        return [
            RegisterMapEntry(address=7, name="Sonda 1", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=8, name="Sonda 2", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=9, name="Sonda 3", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=10, name="Sonda 4", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=11, name="Sonda 5", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=12, name="Sonda 6", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=13, name="Sonda 7", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=0, name="Sd1", unit="°C", data_type="int16", scale_factor=0.1, register_type="holding"),
            RegisterMapEntry(address=39, name="Nastawa (St)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=41, name="Różnica załączania (rd)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=49, name="Próg końca odszraniania (dt1)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=53, name="Dyferencjał resetu alarmu temp. (A0)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=54, name="Próg alarmu niskiej temp. (AL)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=55, name="Próg alarmu wysokiej temp. (AH)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=58, name="Próg załączenia wentylatora (F1)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=59, name="Dyferencjał wentylatora (Frd)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=60, name="Próg wyłączenia wentylatora (F5)", unit="°C", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=61, name="Nastawa przegrzania (P3)", unit="K", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=64, name="Próg niskiego przegrzania (P7)", unit="K", data_type="int16", scale_factor=0.1, writable=True, register_type="holding"),
            RegisterMapEntry(address=168, name="Min. czas włączenia zaworu (c1)", data_type="uint16", register_type="holding"),
            RegisterMapEntry(address=169, name="Min. czas wyłączenia zaworu (c2)", data_type="uint16", register_type="holding"),
            RegisterMapEntry(address=170, name="Maks. czas włączenia zaworu (c3)", data_type="uint16", register_type="holding"),
            RegisterMapEntry(address=93, name="Nastawa Abs/wzgl. (A1)", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=12, name="Błąd czujnika S1 (rE1)", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=13, name="Błąd czujnika S2", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=14, name="Błąd czujnika S3", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=15, name="Błąd czujnika S4", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=16, name="Błąd czujnika S5", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=23, name="Alarm niskiej temperatury (LO)", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=24, name="Alarm wysokiej temperatury (HI)", data_type="uint16", register_type="coil"),
            RegisterMapEntry(address=114, name="Przekaźnik alarmowy (zbiorczy)", data_type="uint16", is_alarm_register=True, register_type="coil"),
        ]

    def identify(self, model_hint: Optional[str] = None) -> ControllerModel:
        return ControllerModel(model=model_hint or "MPXPRO", description="Sterownik Carel MPXPRO (Sonda 1, nastawy, alarmy - zweryfikowane na sprzęcie)")

    def known_alarm_codes(self) -> List[AlarmDescription]:
        return [
            AlarmDescription(code=1, name="ALM", description="Aktywny przekaźnik alarmowy (szczegóły w rejestrach LO/HI/rE1)", severity="warning"),
        ]

    def decode_alarm(self, code: int) -> AlarmDescription:
        for alarm in self.known_alarm_codes():
            if alarm.code == code:
                return alarm
        return AlarmDescription(code=code, name=f"ALM{code}", description="Nieznany kod alarmu", severity="info")

    def simulate_reading(self, tick: float) -> Dict[str, dict]:
        room = round(1 + 1.3 * math.sin(tick * 0.065) + random.uniform(-0.2, 0.2), 1)
        return {
            "Sonda 1": {"value": room, "unit": "°C"},
            "Sonda 2": {"value": round(room + 3 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sonda 3": {"value": round(room + 3.1 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sonda 4": {"value": round(room + 3.15 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sonda 5": {"value": round(room + 3.2 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sonda 6": {"value": round(room + 3.25 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sonda 7": {"value": round(room + 3.3 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Sd1": {"value": round(room + 4 + random.uniform(-0.3, 0.3), 1), "unit": "°C"},
            "Nastawa (St)": {"value": 1.0, "unit": "°C"},
            "Różnica załączania (rd)": {"value": 2.0, "unit": "°C"},
            "Próg końca odszraniania (dt1)": {"value": 8.0, "unit": "°C"},
            "Dyferencjał resetu alarmu temp. (A0)": {"value": 2.0, "unit": "°C"},
            "Próg alarmu niskiej temp. (AL)": {"value": 4.0, "unit": "°C"},
            "Próg alarmu wysokiej temp. (AH)": {"value": 10.0, "unit": "°C"},
            "Próg załączenia wentylatora (F1)": {"value": -5.0, "unit": "°C"},
            "Dyferencjał wentylatora (Frd)": {"value": 2.0, "unit": "°C"},
            "Próg wyłączenia wentylatora (F5)": {"value": 50.0, "unit": "°C"},
            "Nastawa przegrzania (P3)": {"value": 7.0, "unit": "K"},
            "Próg niskiego przegrzania (P7)": {"value": 4.0, "unit": "K"},
            "Min. czas włączenia zaworu (c1)": {"value": 0, "unit": ""},
            "Min. czas wyłączenia zaworu (c2)": {"value": 0, "unit": ""},
            "Maks. czas włączenia zaworu (c3)": {"value": 0, "unit": ""},
            "Nastawa Abs/wzgl. (A1)": {"value": 0, "unit": ""},
            "Błąd czujnika S1 (rE1)": {"value": 0, "unit": ""},
            "Błąd czujnika S2": {"value": 0, "unit": ""},
            "Błąd czujnika S3": {"value": 0, "unit": ""},
            "Błąd czujnika S4": {"value": 0, "unit": ""},
            "Błąd czujnika S5": {"value": 0, "unit": ""},
            "Alarm niskiej temperatury (LO)": {"value": 1 if room < 1 else 0, "unit": ""},
            "Alarm wysokiej temperatury (HI)": {"value": 0, "unit": ""},
            "Przekaźnik alarmowy (zbiorczy)": {"value": 0, "unit": ""},
        }
